// src/pages/LoginPage.js
import React from 'react';
import KidPowerHub1 from '../components/KidPowerHub';
function KidPowerHub({ onLogin }) {
    return (
        <div>
            <KidPowerHub1 />
        </div>
    );
}

export default KidPowerHub;